<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Waste Decomposer Monitor</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom styles */
    body {
      background-image: url('https://www.uffizio.com/wp-content/uploads/2020/10/Remote-Solid-Waste-Management-System-02.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-color: rgba(255, 255, 255, 0.5); /* Adjust the opacity here */
    }
    .container {
      margin-top: 20px;
      color: black; /* Ensure text is readable */
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Waste Decomposer Monitor</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact</a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <!-- Alert module -->
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Warning!</strong> Chemical level is low. Chemical adding is needed for decomposition.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>

    <h2 class="text-center mt-4">Home Waste Decomposer Monitor</h2>
    <div class="row">
      <div class="col-md-6">
        <div class="card mt-4">
          <div class="card-body">
            <h5 class="card-title">Waste Level</h5>
            <h2 id="waste-level">0%</h2>
            <div class="progress">
              <div id="waste-progress" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card mt-4">
          <div class="card-body">
            <h5 class="card-title">Methane Level</h5>
            <h2 id="methane-level">0 ppm</h2>
            <div class="progress">
              <div id="methane-progress" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-md-6 offset-md-3">
        <div class="card mt-4">
          <div class="card-body">
            <h5 class="card-title">Decomposition Progress</h5>
            <h2 id="decomposition-level">0%</h2>
            <div class="progress">
              <div id="decomposition-progress" class="progress-bar bg-success" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col text-center">
        <h4 id="suggestion">Decomposer is Safe to Open</h4>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS and jQuery -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- JavaScript for updating sensor values -->
  <script>
    // Function to fetch sensor data from PHP script
    function fetchSensorData() {
      fetch('fetch_sensor_data.php')
        .then(response => response.json())
        .then(data => {
          // Update waste level display
          document.getElementById('waste-level').textContent = data.wasteLevel + '%';
          document.getElementById('waste-progress').style.width = data.wasteLevel + '%';
          document.getElementById('waste-progress').setAttribute('aria-valuenow', data.wasteLevel);

          // Update methane level display
          document.getElementById('methane-level').textContent = data.methaneLevel + ' ppm';
          document.getElementById('methane-progress').style.width = data.methaneLevel + '%';
          document.getElementById('methane-progress').setAttribute('aria-valuenow', data.methaneLevel);

          // Update decomposition level display
          document.getElementById('decomposition-level').textContent = data.decompositionLevel + '%';
          document.getElementById('decomposition-progress').style.width = data.decompositionLevel + '%';
          document.getElementById('decomposition-progress').setAttribute('aria-valuenow', data.decompositionLevel);

          // Suggest whether it's safe to open the decomposer
          let suggestion = "Decomposer is Safe to Open";
          if (data.wasteLevel > 75 || data.methaneLevel > 25) {
            suggestion = "Decomposer is Not Safe to Open";
          }
          document.getElementById('suggestion').textContent = suggestion;
        })
        .catch(error => console.error('Error fetching sensor data:', error));
    }

    // Update sensor data every 5 seconds
    setInterval(fetchSensorData, 5000);

    // Initially call fetchSensorData to load initial data
    fetchSensorData();
  </script>
</body>
</html>
