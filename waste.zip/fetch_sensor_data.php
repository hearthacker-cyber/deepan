<?php
// Database connection parameters
$servername = "localhost";
$dbname = "u632480160_solarhard";
$username = "u632480160_solarhard";
$password = "root@Ershith#89";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch data from the database table
$sql = "SELECT * FROM SensorData5 ORDER BY reading_time DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch data from the result set
    $row = $result->fetch_assoc();

    // Extract sensor values
    $ultrasonicReading = intval($row['value1']); // Ultrasonic sensor data
    $methaneReading = intval($row['value2']); // Gas sensor data

    // Calculate waste level and methane level percentage
    $wasteLevel = intval(($ultrasonicReading / 14) * 100); // Assuming 14cm is 100%
    $methaneLevel = intval(($methaneReading / 900) * 100); // Assuming 900 is 100%

    // Ensure percentage values are within 0 to 100 range
    $wasteLevel = min(max($wasteLevel, 0), 100);
    $methaneLevel = min(max($methaneLevel, 0), 100);

    // Calculate decomposition progress level based on ultrasonic sensor decreasing
    $decompositionLevel = 100 - $wasteLevel;

    // Ensure decomposition level is within 0 to 100 range
    $decompositionLevel = min(max($decompositionLevel, 0), 100);

    // Suggest whether it's safe to open the decomposer
    $suggestion = "Decomposer is Safe to Open";
    if ($wasteLevel > 75 || $methaneLevel > 25) {
        $suggestion = "Decomposer is Not Safe to Open";
    }

    // Prepare JSON response
    $response = array(
        'wasteLevel' => $wasteLevel,
        'methaneLevel' => $methaneLevel,
        'decompositionLevel' => $decompositionLevel,
        'suggestion' => $suggestion
    );

    // Output JSON response
    echo json_encode($response);
} else {
    echo "0 results";
}

$conn->close();
?>
